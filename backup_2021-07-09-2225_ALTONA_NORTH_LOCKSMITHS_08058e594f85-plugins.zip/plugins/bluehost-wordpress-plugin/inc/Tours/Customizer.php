<?php

namespace Newfold\Plugin\Tours;

class Customizer {
    // customizer tour stub
}