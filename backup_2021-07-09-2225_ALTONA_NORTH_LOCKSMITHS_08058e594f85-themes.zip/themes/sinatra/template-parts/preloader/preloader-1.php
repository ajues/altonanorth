<?php
/**
 * The template for displaying page preloader layout 1.
 *
 * @package Sinatra
 * @author  Sinatra Team <hello@sinatrawp.com>
 * @since   1.0.0
 */

?>

<div class="preloader-1">
	<div></div>
</div><!-- END .si-preloader-1 -->
